
#include <iostream>
#include <string>

using namespace std;

// base class
class Shape{
protected:
	string name;
public:
	Shape(string n){
		name = n;
	}
	void setName(string s){
		name = s;
	}
	string getName(){
		return name;
	}
};

// first child class
class Circle : public Shape{

	double radius;

public:
	Circle(string n, double r) : Shape(n) {
		radius = r;
	}

	void setRadius(double r){
		radius = r;
	}

	double getRadius() const{
		return radius;
	}

	double getArea() const{
		return 3.14 * radius * radius;
	}

};

// second child class
class Rectangle : public Shape{
	double length, width;
public:
	Rectangle(string n, double w, double l) : Shape(n) {
		width = w;
		length = l;
	}
	void setWidth(double w){
		width = w;
	}
	void setLength(double l){
		length = l;
	}
	double getWidth(){
		return this->width;
	}
	double getLength(){
		return this->length;
	}

	double getArea(){
		return this->length * this->width;
	}
};

// third child class
class Triangle : public Shape{

	double base, height;
public:
	Triangle(string n, double h, double b) : Shape(n) {
		height = h;
		base = b;
	}
	void setHeight(double h){
		height = h;
	}
	void setBase(double b){
		base = b;
	}
	double getHeight(){
		return this->height;
	}
	double getBase(){
		return this->base;
	}
	double getArea(){
		return (0.5 * this->base) * this->height;
	}
};

int main(){

	Shape s("All Shapes");
	cout << s.getName() << endl;



	Circle c("Circle", 3.1);
	c.setName("Circle TOO");
	cout << "The area of " << c.getName() << "( 3.14 * 2 * " << c.getRadius() << " ) is : " << c.getArea() << endl;

	Rectangle r("Rectangle", 4.2, 2.5);
	cout << "The area of " << r.getName() << "( " << r.getWidth() << " x " << r.getLength() << " ) is : " << r.getArea() << endl;

	Triangle t("Triangle", 4, 3);
	cout << "The area of " << t.getName() << "( 1/2 x " << t.getBase() << " x " << t.getHeight() << " ) is : " << t.getArea() << endl;


	return 0;
}