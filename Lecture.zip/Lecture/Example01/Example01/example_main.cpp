#include "example.h"

int main(){

	example anObject;

	anObject.printFunction();

	return 0;
}
