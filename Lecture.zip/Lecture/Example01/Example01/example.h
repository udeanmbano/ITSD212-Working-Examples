#ifndef Example_H
#define Example_H

class example
{
private:
	int a_var;

public:
	example();
	void getFunction();
	void setFunction();
	void printFunction();
};

#endif