//without copy constructor it will not work
#include <iostream>
#include <string>

using namespace std;

class Square
{
private:
	int *width;
	int length;

public:
	Square(int w, int l)
	{
		this->width = new int(w);
		this->length = l;
	}
	/*
	Square(const Square &s)
	{
	cout << "activated" << endl;
	width = new int(*s.width);
	length = s.length;
	}
	*/
	void setDimension(int w, int l)
	{
		*(this->width) = w;
		this->length = l;
	}

	void printArea()
	{
		cout << " The area of  " << *width << " and " << length << " is : " << *width * length << endl;
	}

};

int main()
{
	Square s1(4, 4);
	s1.printArea();


	Square s2 = s1;
	s2.printArea();

	s1.setDimension(5, 5);
	s1.printArea();
	//pointer does change value since it pints to the value in the memory location so we have to use copy constructor so it remains 4
	s2.printArea();

	return 0;
}