#include <iostream>
using namespace std;

int main(){

	const int MAX = 4;
	int arr[MAX] = { 5, 10, 15, 20 };

	for (int i = 0; i < MAX; i++){
		cout << arr[i] << " ";
	}

	cout << endl;

	int *ptr = &arr[0];
	cout << "=> " << *ptr << " " << *(ptr + 1) << endl;
	for (int i = 0; i < MAX; i++){
		cout << *(ptr + i) << " ";
	}

	cout << endl;

	cout << "=> " << *arr << " " << *(arr + 1) << endl;
	for (int i = 0; i < MAX; i++){
		cout << *(arr + i) << " ";
	}


	return 0;



}