#include <iostream>
using namespace std;

class Integer
{
private:
	int* intptr;

public:
	Integer()
	{
		intptr = new int;
	}
	Integer(int i)
	{
		intptr = new int;
		*intptr = i;
	}

	void setValue(int i)
	{
		*intptr = i;
	}

	int getValue() const
	{
		return *intptr;
	}

};

int main()
{
	Integer i, j(10);
	i.setValue(5);

	cout << i.getValue() << endl;
	cout << j.getValue() << endl;

	return 0;
}