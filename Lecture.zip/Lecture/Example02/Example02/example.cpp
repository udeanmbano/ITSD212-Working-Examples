#include <iostream>
#include "example.h"

using namespace std;



example::example(){

}

void example::setFunction(int par_x){
	a_var = par_x;
}

int example::getFunction(){
	cout << "Enter a value : ";
	cin >> new_var;

	return new_var;
}
void example::printFunction() {

	cout << endl << "Value : " << a_var << endl;
}